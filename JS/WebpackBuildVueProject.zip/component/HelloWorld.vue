<template>
        <div>
             <div id="parent">
                 Hello World
             </div>
        </div>
</template>

<script>
    export default {
        name: "HelloWorld"
    }
</script>

<style scoped lang="scss">
        $bgColor:red;
        #parent{
            color:$bgColor;
        }
</style>