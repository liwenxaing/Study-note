<template>
     <div id="app">
            <HelloWorld/>
     </div>
</template>

<script>

    import HelloWorld from '../component/HelloWorld.vue'

    export default {
        name: "App",
        components:{HelloWorld},
        data(){
            return {

            }
        }
    }
</script>

<style>
    #app{
        text-align: center;
        font-size:16px;
        vertical-align: middle;
        font-family: "Consolas", "Monaco", "Bitstream Vera Sans Mono", "Courier New", Courier, monospace;
    }
</style>