// postcss.config.js
// 自动添加css兼容属性
module.exports = {
    plugins: [
        require('autoprefixer')
    ]
}